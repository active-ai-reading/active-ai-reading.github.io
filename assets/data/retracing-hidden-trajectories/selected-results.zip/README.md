# Selected hidden-state trajectory results

Four examples from the 22-prompt run. No new inference or PCA fitting was done for the post. The NPZ files contain all tokens' saved PC1–PC3 coordinates and full-space movement metrics; trial.json and run-manifest.json record exact prompts, seed, precision, and model revision. The original full hidden states and output probabilities were not saved. The post's interactive views translate the coordinates and zoom; numerical arrays are unchanged.
